# Organic HVAC Repair State College — Unofficial Concept

This is a static, responsive website demo. It is not affiliated with Organic HVAC Repair State College.

## Preview
Open `index.html` locally, or upload this folder to GitHub and enable GitHub Pages (Settings → Pages → Deploy from branch), or connect the repository to Cloudflare Pages.

## Before going live
- Obtain business permission and confirm the legal business name and services.
- Replace the unofficial concept banner with approved branding.
- Confirm service area, business hours, contact details, credentials, and customer review text/rating.
- Connect the contact form to a real submission endpoint (currently it is a demo only).
- Add privacy policy and any legally required disclosures.
- Confirm licenses for any images/assets added later.
- Have the client create their own hosting and domain accounts for ownership.

## Files
`index.html`, `styles.css`, `script.js`.
